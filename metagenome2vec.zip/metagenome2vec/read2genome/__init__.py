__all__ = ["read2genome3.py"]
